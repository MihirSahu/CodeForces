#include <iostream>
using namespace std;

int main() {
	int m, n;
	cin >> m >> n;
	cout << int((m * n) / 2);
}
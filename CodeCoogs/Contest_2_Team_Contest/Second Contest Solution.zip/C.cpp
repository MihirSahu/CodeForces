#include <iostream>
using namespace std;

int main() {
	int n, k, w;
	cin >> k >> n >> w;
	int t = 0;
	for (int i = 1; i <= w; i++)
		t += i * k;
	if (t < n) cout << 0;
	else cout << t - n;
}
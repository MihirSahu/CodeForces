#include <iostream>
#include <string>
using namespace std;

int main() {
	int n;
	cin >> n;
	string arr[110];
	int count = 0;
	string s;
	for (int i = 0; i < n; i++) {
		cin >> s;
		int t = s.length() - 2;
		if (s.length() > 10) arr[count] = s[0] + std::to_string(t) + s[s.length() - 1];
		else arr[count] = s;
		count++;
	}
	for (int i = 0; i < count; i++)
		cout << arr[i] << endl;
}
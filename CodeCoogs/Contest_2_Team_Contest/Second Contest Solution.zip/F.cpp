#include <iostream>
#include <algorithm>
#include <vector>
#include "math.h"
using namespace std;

int main() {
    int t;
    cin >> t;
    long long int a, b, n, S;
    while (t--) {
        cin >> a >> b >> n >> S;
        if (a * n <= S) {
            if (a * n + b >= S) cout << "YES" << endl;
            else cout << "NO" << endl;
        }
        else {
            if (S % n <= b) cout << "YES" << endl;
            else cout << "NO" << endl;
        }
    }
}
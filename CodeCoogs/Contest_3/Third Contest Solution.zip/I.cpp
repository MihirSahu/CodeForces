#include <iostream>
#include <math.h>
#include <string>
#include <vector>

using namespace std;
typedef long long int lli;

int main() {
    int t;
    lli a, b;
    lli n;
    cin >> t;
    while (t--) {
        cin >> a >> b;
        n = a + b;
        if (b % a == 0) cout << a << endl;
        else if (a > b) {
            cout << n << endl;
        }
        else if (b > a) {
            int t = a * (b / a);
            t = (b + t) / 2;
            cout << t << endl;
        }
    }
}
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;

int main() {
	int t;
	cin >> t;
	int a, b;
	while (t--) {
		cin >> a >> b;
		if (a < b) { int tmp = a; a = b; b = tmp; }
		int tmp = floor((a + b) / 4);
		if (tmp > b) cout << b << endl;
		else cout << tmp << endl;
	}
}
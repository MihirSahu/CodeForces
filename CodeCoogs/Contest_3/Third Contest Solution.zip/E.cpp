#include <iostream>
#include <math.h>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;
typedef long long int lli;

int main() {
    int t;
    int n;
    cin >> t;
    while (t--) {
        cin >> n;
        vector<int> a(n);
        vector<int> b(n);
        for (int i = 0; i < n; i++)
            cin >> a[i];
        for (int i = 0; i < n; i++)
            cin >> b[i];
        std::sort(a.begin(), a.end());
        std::sort(b.begin(), b.end());
        bool check = true;
        for (int i = 0; i < n; i++)
            if (a[i] != b[i] && a[i] != b[i] - 1) {
                check = false;
                break;
            }
        if (check) cout << "YES" << endl;
        else cout << "NO" << endl;
    }
}
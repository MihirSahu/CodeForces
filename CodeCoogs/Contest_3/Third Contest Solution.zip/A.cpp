#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
#include <vector>
#include <map>
using namespace std;

int main() {
    int t;
    int n, m;
    cin >> t;
    bool a[1010][5];
    while (t--) {
        cin >> n;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < 5; j++)
                cin >> a[i][j];

        string res = "NO";
        for (int i = 0; i < 4; i++) {
            for (int j = i + 1; j < 5; j++) {
                int cnt = 0;
                int cnt1 = 0;
                int cnt2 = 0;
                map<int, int> check;
                for (int k = 0; k < n; k++) {
                    if (a[k][i] == 1) {
                        if (check[k] == 0) {
                            check[k] = 1;
                            cnt++;
                        }
                        cnt1++;
                    }
                    if (a[k][j] == 1) {
                        if (check[k] == 0) {
                            check[k] = 1;
                            cnt++;
                        }
                        cnt2++;
                    }
                }
                if (cnt == n && cnt1 >= n / 2 && cnt2 >= n / 2) {
                    res = "YES";
                    break;
                }
            }
            if (res == "YES") break;
        }

        cout << res << endl;
    }
}
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;

int main() {
	int t;
	cin >> t;
	int n;
	while (t--) {
		cin >> n;
		if (n % 2 == 0) cout << 0 << endl;
		else {
			bool check = false;
			while (n > 10) {
				if (n % 2 == 0) check = true;
				n = n / 10;
			}
			if (n % 2 == 0) cout << 1 << endl;
			else if (check == true) cout << 2 << endl;
			else cout << "-1" << endl;
		}
	}
}
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
#include <vector>
using namespace std;

int main() {
	int t;
	cin >> t;
	int n;
	int arr[200010];
	vector<int> res(400010);
	while (t--) {
		cin >> n;
		for (int i = 0; i < n; i++)
			cin >> arr[i];
		if (n - 1 >= 0)
			if (arr[0] != n && arr[n - 1] != n) {
				cout << -1 << endl;
				continue;
			}
		int l = 0;
		int r = n - 1;
		int insert_l = 200000;
		int insert_r = 200001;
		while (r - l + 1 > 0) {
			if (arr[l] > arr[r]) {
				res[insert_l] = arr[l];
				l++;
				insert_l--;
			}
			else {
				res[insert_r] = arr[r];
				r--;
				insert_r++;
			}
		}
		for (int i = insert_l + 1; i <= insert_r - 1; i++)
			cout << res[i] << " ";
		cout << endl;
	}
}
#include <iostream>
#include <string>
using namespace std;

int main() {
	string t;
	getline(cin, t);

	for (int i = 0; i < stoi(t); i++) {
		string s;
		int count = 0;
		int res = 100000;
		getline(cin, s);
		int j = s.length() - 1;
		while (j > 0 && s[j] != '0') {
			count++;
			j--;
		}
		if (j > 0) {
			j--;
			while (j >= 0 && s[j] != '0' && s[j] != '5') {
				count++;
				j--;
			}
			if (j >= 0 && count < res) res = count;
		}
		j = s.length() - 1;
		count = 0;
		while (j > 0 && s[j] != '5') {
			count++;
			j--;
		}
		if (j > 0) {
			j--;
			while (j >= 0 && s[j] != '2' && s[j] != '7') {
				count++;
				j--;
			}
			if (j >= 0 && count < res) res = count;
		}
		cout << res << endl;
	}
}
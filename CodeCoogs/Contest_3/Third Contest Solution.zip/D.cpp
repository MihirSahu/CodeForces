#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
#include <vector>
#include <map>
using namespace std;

int main() {
    int t;
    cin >> t;
    int n;
    while (t--) {
        cin >> n;
        vector<int> b(n + 1);
        vector<int> d(n + 1);
        for (int i = 1; i <= n; i++) {
            cin >> b[i];
            d[i] = -1;
        }
        int p;
        bool check = true;
        for (int i = 0; i < n; i++) {
            cin >> p;
            if (check && (d[b[p]] != -1 || p == b[p])) d[p] = i;
            if (d[b[p]] == -1) check = false;

        }
        if (check == false) cout << -1;
        else
            for (int i = 1; i <= n; i++)
                cout << d[i] - d[b[i]] << " ";
        cout << endl;
    }
}